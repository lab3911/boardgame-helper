# Cloudflare Worker Proxy

Deploy this worker and set a secret `OPENAI_API_KEY`. Then use its URL in Settings.