
# Boardgame Helper — Lab391 (Pro)

A modern, professional, single-page web app for running your game nights:
- Clean multi-tab UI (Dashboard, Scorekeeper, Turns & Timer, Tools, Game Library, AI Assistant, Settings)
- Powerful scorekeeper with rounds, totals, export/import
- Turn tracker + per-turn timer with sound
- Dice, coin flip, and card drawer utilities
- Game library with notes, links, tags, and search
- AI Assistant per game with optional proxy to protect your API key
- PWA: works offline, installable

## Quick Start (GitHub Pages)
1. Create (or open) your `lab3911/boardgame-helper` repo.
2. Upload the contents of this zip at the repo root.
3. Enable GitHub Pages on the `main` branch. Done.

## Optional: Enable AI via Proxy
GitHub Pages is static, so use a tiny proxy (e.g., Cloudflare Worker in `proxy-example/`) to keep your API key safe.
- Deploy the worker and add a secret `OPENAI_API_KEY`.
- In the app (Settings tab), set **Proxy Endpoint** to your worker URL ending with `/v1/chat/completions` and paste a token if your worker checks one (not required in sample).

## Data
All data (tables, notes, library) is stored locally in the browser (localStorage). Use Backup to export/import JSON.

## Customization
- Colors/themes: edit `assets/css/style.css`
- App logic: `assets/js/app.js`
- Icons: `assets/img/*`

---
© Boardgame Lab391
